import os
import sys
import argparse
import glob


def check_dependencies():
    required = {
        'flask': 'Flask',
        'transformers': 'transformers',
        'torch': 'torch',
        'PIL': 'pillow',
        'werkzeug': 'Werkzeug',
        'numpy': 'numpy',
        'openai': 'openai',
    }

    missing = []
    for module, package in required.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)

    try:
        __import__('pdf2image')
        print("✓ PDF处理支持已启用 (pdf2image)")
    except ImportError:
        print("⚠ PDF处理未启用，安装: pip install pdf2image poppler-utils")

    if missing:
        print(f"✗ 缺少依赖: {', '.join(missing)}")
        print(f"请运行: pip install {' '.join(missing)}")
        return False

    print("✓ 所有核心依赖检查通过")
    print("✓ OpenAI SDK 已安装（用于 moonshot API）")
    return True


def find_model_path(weights_arg):
    if weights_arg and os.path.exists(weights_arg):
        return weights_arg

    search_paths = []

    if os.path.exists('results'):
        exp_dirs = sorted(glob.glob('results/*/checkpoints/best'), reverse=True)
        search_paths.extend(exp_dirs)

    if os.path.exists('weights'):
        epoch_dirs = []
        for d in glob.glob('weights/epoch_*'):
            try:
                epoch_num = int(d.split('_')[-1])
                epoch_dirs.append((epoch_num, d))
            except:
                pass
        epoch_dirs.sort(reverse=True)
        search_paths.extend([d for _, d in epoch_dirs])

        if os.path.exists('weights/best'):
            search_paths.append('weights/best')

    for path in search_paths:
        if os.path.isdir(path):
            has_hf_model = any(os.path.exists(os.path.join(path, f)) for f in
                               ['pytorch_model.bin', 'model.safetensors', 'model.safetensors.index.json'])
            has_config = os.path.exists(os.path.join(path, 'config.json'))

            if has_hf_model and has_config:
                prob_path = os.path.join(path, 'probModule.pt')
                print(f"✓ 找到有效模型: {path}")
                print(f"  - HuggingFace模型 (Encoder): ✓")
                print(f"  - ProbModule: {'✓' if os.path.exists(prob_path) else '✗ (将使用随机初始化)'}")
                print(f"  - Decoder: 不使用（moonshot API）")
                return path

    return None


def verify_model_contents(model_path):
    print(f"\n验证模型内容: {model_path}")

    if not os.path.exists(model_path):
        print(f"✗ 路径不存在")
        return False

    files = os.listdir(model_path)
    print(f"文件列表: {files}")

    has_hf_config = 'config.json' in files
    has_hf_model = any(f in files for f in ['pytorch_model.bin', 'model.safetensors', 'model.safetensors.index.json'])
    has_prob = 'probModule.pt' in files

    print(f"\n检查结果:")
    print(f"  HuggingFace配置 (config.json): {'✓' if has_hf_config else '✗'}")
    print(f"  HuggingFace模型权重 (Encoder): {'✓' if has_hf_model else '✗'}")
    print(f"  ProbModule权重: {'✓' if has_prob else '✗'}")

    if not has_hf_model:
        print(f"\n✗ 错误: 缺少HuggingFace模型权重文件!")
        return False

    config_path = os.path.join(model_path, 'config.json')
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                config = json.load(f)
            epoch = config.get('epoch', 'unknown')
            print(f"\n模型信息:")
            print(f"  训练轮次: {epoch}")
            print(f"  推理模式: SASP选页 + moonshot答案生成")
        except:
            pass

    return True


def main():
    parser = argparse.ArgumentParser(
        description='启动多页文档视觉问答Web服务（SASP选页 + moonshot答案生成）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  pip3 install openai flask transformers torch pillow werkzeug numpy
  python run.py
  python run.py --weights results/transformer_20240324_123456/checkpoints/best
  python run.py --moonshot-key sk-xxxxx
  export moonshot_API_KEY=sk-xxxxx && python run.py
  python run.py --port 8080 --host 127.0.0.1
        """
    )

    parser.add_argument('--port', type=int, default=5000, help='服务端口 (默认: 5000)')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='绑定地址')
    parser.add_argument('--weights', type=str, default=None, help='模型路径')
    parser.add_argument('--base-model', type=str, default='google/pix2struct-base', help='基础模型名称')
    parser.add_argument('--moonshot-key', type=str, default=None, help='moonshot API')
    parser.add_argument('--upload-limit', type=int, default=50, help='上传文件大小限制MB')
    parser.add_argument('--no-pdf', action='store_true', help='禁用PDF处理')
    parser.add_argument('--device', type=str, default=None, help='强制使用设备')

    args = parser.parse_args()

    print("=" * 60)
    print("检查依赖...")
    if not check_dependencies():
        sys.exit(1)

    print("\n查找模型...")
    model_path = find_model_path(args.weights)

    if not model_path:
        print("\n✗ 未找到有效的训练模型!")
        print("\n请确保已运行训练脚本，或手动指定路径:")
        print("  python train.py --facil")
        print("  python run.py --weights weights/epoch_1")
        sys.exit(1)

    if not verify_model_contents(model_path):
        print("\n✗ 模型验证失败!")
        sys.exit(1)

    api_key = args.moonshot_key or os.environ.get('moonshot_API_KEY')

    if api_key:
        os.environ['moonshot_API_KEY'] = api_key
        masked = api_key[:10] + "..." + api_key[-4:] if len(api_key) > 14 else "***"
        print(f"\n✓ 使用自定义 moonshot API 密钥: {masked}")
    else:
        print("\n! 未提供自定义密钥，将使用代码中的默认密钥")

    os.environ['MODEL_PATH'] = model_path
    os.environ['BASE_MODEL'] = args.base_model
    os.environ['UPLOAD_LIMIT_MB'] = str(args.upload_limit)
    os.environ['DISABLE_PDF'] = '1' if args.no_pdf else '0'

    if args.device:
        device = args.device
    else:
        device = 'cuda' if os.system('nvidia-smi > /dev/null 2>&1') == 0 else 'cpu'
    os.environ['FORCE_DEVICE'] = device

    print(f"""
    多页文档视觉问答系统
    SASP页面选择 + 答案生成

    服务地址: http://{args.host}:{args.port}
    上传限制: {args.upload_limit} MB
    模型路径: {model_path[-42:]}
    设备: {device}
    PDF处理: {'禁用' if args.no_pdf else '启用'}
    Moonshot API: {'已配置' if api_key else '使用默认'}

    处理流程:
      1. SASP模块计算各页面与问题的相关性分数
      2. 选取得分最高的3个页面
      3. Moonshot API识别选中页面内容并生成答案

    接口: /api/health, /api/upload, /api/upload/pdf
          /api/ask, /api/ask/batch
    """)

    try:
        from app import app
        app.run(host=args.host, port=args.port, debug=False, threaded=True)
    except Exception as e:
        print(f"\n启动失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    import json

    main()