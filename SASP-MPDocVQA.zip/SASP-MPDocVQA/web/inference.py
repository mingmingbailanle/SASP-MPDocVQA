import os
import sys
import json
import base64
import torch
import numpy as np
from PIL import Image
from typing import List, Dict, Optional, Union
from dataclasses import dataclass
from tqdm import tqdm
import argparse

# 导入模型相关
from transformers import Pix2StructProcessor, Pix2StructForConditionalGeneration
from prob_model import ProbModule

# ==================== moonshot API 配置 ====================

try:
    from openai import OpenAI
except ImportError:
    print("错误: 请先安装 OpenAI SDK: pip3 install openai")
    sys.exit(1)

moonshot_API_KEY = os.environ.get("moonshot_API_KEY", "")
moonshot_BASE_URL = "https://api.moonshot.cn/v1"


@dataclass
class InferenceResult:
    """推理结果数据结构"""
    question: str
    selected_pages: List[int]
    page_scores: List[float]
    page_weights: List[float]
    all_page_probs: List[float]
    answer: str
    api_usage: Dict
    metadata: Dict
    strategy: str = ""


class moonshotClient:
    # moonshot API 客户端

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        self.api_key = api_key or moonshot_API_KEY
        self.base_url = base_url or moonshot_BASE_URL

        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url
        )

        masked_key = self.api_key[:10] + "..." + self.api_key[-4:] if len(self.api_key) > 14 else "***"
        print(f"✓ moonshot 客户端初始化: {masked_key}")

    def _encode_image(self, image_path: Union[str, Image.Image]) -> str:
        if isinstance(image_path, str):
            with open(image_path, "rb") as f:
                image_data = f.read()
        else:
            import io
            buffer = io.BytesIO()
            image_path.save(buffer, format="PNG")
            image_data = buffer.getvalue()
        return base64.b64encode(image_data).decode('utf-8')

    def ask(self, question: str, image_paths: List[str], system_prompt: Optional[str] = None) -> Dict:
        default_system = """你是一个专业的文档理解助手。用户提供了文档的某些页面图片和一个问题。
请仔细查看图片中的文字、表格、图表等内容，准确用中文回答用户的问题。
如果图片中没有相关信息，请明确说明"根据提供的页面，无法找到答案"。
回答要简洁准确，直接针对问题作答，不要添加无关解释。"""

        system = system_prompt or default_system

        content = [{"type": "text", "text": f"问题：{question}\n\n请根据以下文档页面图片回答上面的问题。"}]

        for idx, img_path in enumerate(image_paths, 1):
            try:
                base64_image = self._encode_image(img_path)
                content.append({
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/png;base64,{base64_image}",
                        "detail": "high"
                    }
                })
            except Exception as e:
                print(f"图片编码失败 {img_path}: {e}")
                continue

        try:
            response = self.client.chat.completions.create(
                model="moonshot-v1-8k-vision-preview",
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": content}
                ],
                max_tokens=1024,
                temperature=0.2,
                stream=False
            )

            return {
                "answer": response.choices[0].message.content,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                    "total_tokens": response.usage.total_tokens if response.usage else 0
                },
                "success": True
            }

        except Exception as e:
            error_msg = str(e)
            print(f"\nmoonshot API 错误: {error_msg}")
            return {
                "answer": f"API调用失败: {error_msg}",
                "usage": {},
                "error": error_msg,
                "success": False
            }


class PageSelector:
    # 页面选择器

    def __init__(self, device: str = "cuda"):
        self.device = device

    def top_3(self, probs: np.ndarray) -> type:
        """固定选择概率最高的前3页"""
        # 获取概率最高的3个索引
        top_indices = np.argsort(probs)[::-1][:3]
        selected = [int(i) for i in top_indices]

        # 如果文档不足3页，按实际页数选择
        if len(probs) < 3:
            selected = [int(i) for i in np.argsort(probs)[::-1][:len(probs)]]

        scores = [float(probs[i]) for i in selected]
        weights = [s / sum(scores) for s in scores] if sum(scores) > 0 else [1.0 / len(selected)] * len(selected)

        return type('SelectionResult', (), {
            'selected_pages': selected,
            'scores': scores,
            'weights': weights,
            'metadata': {'k': min(3, len(probs))},
            'strategy': 'top_3'
        })()


class DocVQAInference:
    # DocVQA推理流程 - SASP选页 + moonshot回答

    def __init__(self,
                 model_path: str,
                 prob_module_path: Optional[str] = None,
                 device: str = "cuda",
                 api_key: Optional[str] = None,
                 base_url: Optional[str] = None):

        self.device = torch.device(device if torch.cuda.is_available() else "cpu")

        print(f"\n{'=' * 60}")
        print(f"Loading models on {self.device}...")
        print(f"Model path: {model_path}")
        print(f"Page selection: SASP top-3 + moonshot answer generation")

        # 验证 model_path
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model path not found: {model_path}")

        # 1. 加载 HuggingFace 模型 (Encoder + Decoder)
        print("\n[1/3] Loading HuggingFace Model (Pix2Struct)...")
        try:
            self.processor = Pix2StructProcessor.from_pretrained(model_path, use_fast=False)
            self.encoder_model = Pix2StructForConditionalGeneration.from_pretrained(model_path).to(self.device)
            self.encoder = self.encoder_model.encoder
            print(f"  ✓ Loaded HF model from {model_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to load HF model: {e}")

        # 冻结 encoder
        self.encoder.eval()
        for param in self.encoder.parameters():
            param.requires_grad = False

        # 冻结 decoder（使用 moonshot API 替代）
        self.encoder_model.decoder.eval()
        for param in self.encoder_model.decoder.parameters():
            param.requires_grad = False

        # 2. 加载 ProbModule
        print("\n[2/3] Loading ProbModule...")
        self.prob_module = ProbModule().to(self.device)

        # 自动推导 prob_module_path
        if prob_module_path is None:
            prob_module_path = os.path.join(model_path, 'probModule.pt')
            print(f"  Auto-derived prob_module_path: {prob_module_path}")

        if not os.path.exists(prob_module_path):
            parent_dir = os.path.dirname(model_path)
            alt_paths = [
                os.path.join(parent_dir, 'probModule.pt'),
                os.path.join(parent_dir, f'epoch_{self._get_epoch_from_path(model_path)}', 'probModule.pt'),
            ]
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    prob_module_path = alt_path
                    print(f"  Found probModule at alternative path: {prob_module_path}")
                    break

        if not os.path.exists(prob_module_path):
            raise FileNotFoundError(
                f"ProbModule not found at {prob_module_path}. "
                f"Please ensure probModule.pt exists in the model directory, "
                f"or specify --prob_module_path explicitly."
            )

        try:
            prob_state = torch.load(prob_module_path, map_location=self.device)
            self.prob_module.load_state_dict(prob_state)
            self.prob_module.eval()
            for param in self.prob_module.parameters():
                param.requires_grad = False
            print(f"  ✓ Loaded ProbModule from {prob_module_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to load ProbModule: {e}")

        # 3. 初始化其他组件
        print("\n[3/3] Initializing PageSelector and moonshotClient...")
        self.page_selector = PageSelector(device=str(self.device))
        self.moonshot_client = moonshotClient(api_key=api_key, base_url=base_url)

        print(f"\n{'=' * 60}")
        print("✓ All models loaded successfully!")
        print(f"{'=' * 60}\n")

    def _get_epoch_from_path(self, path: str) -> int:
        """从路径中提取epoch数字"""
        import re
        match = re.search(r'epoch_(\d+)', path)
        return int(match.group(1)) if match else 0

    @torch.no_grad()
    def get_page_relevance(self, image_patches: torch.Tensor, patches_masks: torch.Tensor) -> np.ndarray:
        enc_outputs = self.encoder(image_patches, patches_masks)
        enc_feat = torch.permute(enc_outputs.last_hidden_state, (0, 2, 1))
        page_probs = self.prob_module(enc_feat, patches_masks)
        return page_probs.cpu().numpy()

    def select_pages(self, page_probs: np.ndarray):
        """SASP固定选择概率最高的前3页"""
        return self.page_selector.top_3(page_probs)

    def prepare_inputs(self, doc_images: List[Union[str, Image.Image]], question: str) -> Dict:
        all_patches = []
        all_masks = []

        for img in doc_images:
            if isinstance(img, str):
                img = Image.open(img).convert('RGB')

            inputs = self.processor(
                images=img,
                text=question,
                return_tensors="pt"
            )

            if 'flattened_patches' in inputs:
                patches = inputs['flattened_patches'].squeeze(0)
            else:
                patches = inputs['pixel_values'].squeeze(0)

            all_patches.append(patches)
            seq_len = patches.shape[0]
            all_masks.append(torch.ones(seq_len))

        max_len = max(p.shape[0] for p in all_patches)
        padded_patches = []
        padded_masks = []

        for p, m in zip(all_patches, all_masks):
            pad_len = max_len - p.shape[0]
            if pad_len > 0:
                pad = torch.zeros(pad_len, p.shape[1]) if len(p.shape) > 1 else torch.zeros(pad_len)
                p = torch.cat([p, pad], dim=0)
                m = torch.cat([m, torch.zeros(pad_len)], dim=0)

            padded_patches.append(p)
            padded_masks.append(m)

        return {
            "image_patches": torch.stack(padded_patches).to(self.device),
            "patches_masks": torch.stack(padded_masks).to(self.device),
            "raw_images": doc_images
        }

    def inference(self, doc_images: List[Union[str, Image.Image]], question: str,
                  return_intermediate: bool = False) -> InferenceResult:
        print(f"\nProcessing {len(doc_images)} pages...")
        inputs = self.prepare_inputs(doc_images, question)

        print("Computing SASP page relevance scores...")
        page_probs = self.get_page_relevance(inputs["image_patches"], inputs["patches_masks"])
        print(f"  SASP All page scores: {[f'{p:.3f}' for p in page_probs]}")

        # SASP选择前3页
        selection = self.select_pages(page_probs)
        selected_indices = selection.selected_pages
        selected_scores = selection.scores

        print(f"  SASP Selected pages (Top 3): {selected_indices}")
        print(f"  SASP Page scores: {[f'{s:.3f}' for s in selected_scores]}")

        # moonshot只负责识别选出的页面并回答
        selected_images = [doc_images[i] for i in selected_indices]
        api_result = self.moonshot_client.ask(question, selected_images)

        answer = api_result["answer"]
        print(f"  Generated answer: {answer[:100]}...")

        return InferenceResult(
            question=question,
            selected_pages=selected_indices,
            page_scores=selected_scores,
            page_weights=selection.weights,
            all_page_probs=page_probs.tolist(),
            answer=answer,
            api_usage=api_result.get("usage", {}),
            metadata={"total_pages": len(doc_images), "api_success": api_result.get("success", False)},
            strategy=selection.strategy
        )

    def batch_inference(self, samples: List[Dict], output_path: Optional[str] = None) -> List[InferenceResult]:
        results = []

        for idx, sample in enumerate(tqdm(samples, desc="Processing samples")):
            try:
                result = self.inference(doc_images=sample["images"], question=sample["question"])
                results.append(result)
                print(
                    f"[{idx + 1}/{len(samples)}] SASP Pages: {result.selected_pages}, "
                    f"Scores: {[f'{s:.2f}' for s in result.page_scores]}, "
                    f"Answer: {result.answer[:50]}...")
            except Exception as e:
                print(f"Error processing sample {idx}: {e}")
                import traceback
                traceback.print_exc()
                results.append(None)

        if output_path:
            self._save_results(results, output_path)

        return results

    def _save_results(self, results: List[InferenceResult], path: str):
        output = []
        for r in results:
            if r is None:
                continue
            output.append({
                "question": r.question,
                "selected_pages": r.selected_pages,
                "page_scores": r.page_scores,
                "page_weights": r.page_weights,
                "all_page_probs": r.all_page_probs,
                "answer": r.answer,
                "api_usage": r.api_usage,
                "strategy": r.strategy,
                "metadata": r.metadata
            })

        with open(path, 'w', encoding='utf-8') as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

        print(f"\nResults saved to: {path}")


def main():
    parser = argparse.ArgumentParser(description="DocVQA Inference with SASP Top-3 Page Selection + moonshot API")

    parser.add_argument("--model_path", type=str, required=True,
                        help="训练好的模型目录路径，如 results/transformer_20240324_123456/checkpoints/best")
    parser.add_argument("--prob_module_path", type=str, default=None,
                        help="ProbModule.pt路径（可选，默认从model_path自动查找）")
    parser.add_argument("--api_key", type=str, default=None,
                        help="moonshot API密钥（可选，默认使用环境变量或代码中的默认值）")
    parser.add_argument("--base_url", type=str, default=None,
                        help="moonshot API基础URL（可选）")
    parser.add_argument("--input", type=str, required=True,
                        help="输入JSON文件路径，包含images和question字段")
    parser.add_argument("--output", type=str, default="results.json",
                        help="输出结果文件路径")
    parser.add_argument("--device", type=str, default="cuda",
                        help="计算设备（cuda或cpu）")

    args = parser.parse_args()

    # 验证输入文件
    if not os.path.exists(args.input):
        raise FileNotFoundError(f"Input file not found: {args.input}")

    # 初始化推理器
    inferencer = DocVQAInference(
        model_path=args.model_path,
        prob_module_path=args.prob_module_path,
        device=args.device,
        api_key=args.api_key,
        base_url=args.base_url
    )

    # 加载输入样本
    with open(args.input, 'r', encoding='utf-8') as f:
        samples = json.load(f)

    print(f"\nLoaded {len(samples)} samples from {args.input}")

    # 执行推理
    results = inferencer.batch_inference(samples, args.output)

    # 统计信息
    total_pages = sum(len(r.selected_pages) for r in results if r)
    avg_pages = total_pages / len([r for r in results if r]) if any(r for r in results) else 0

    print(f"\n{'=' * 60}")
    print(f"Completed!")
    print(f"Total samples: {len(results)}")
    print(f"Successful: {len([r for r in results if r])}")
    print(f"Average pages selected: {avg_pages:.2f}")
    print(f"Results saved to: {args.output}")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()