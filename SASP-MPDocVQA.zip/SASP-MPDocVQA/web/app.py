from flask import Flask, request, jsonify, render_template, send_from_directory
import os
import sys
import json
import uuid
import time
import base64
import re
import numpy as np
import torch
from werkzeug.utils import secure_filename
from PIL import Image

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'pdf', 'tiff', 'webp'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = int(os.environ.get('UPLOAD_LIMIT_MB', 50)) * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ==================== moonshot API 配置 ====================

try:
    from openai import OpenAI
except ImportError:
    print("错误: 请先安装 OpenAI SDK: pip3 install openai")
    sys.exit(1)

moonshot_API_KEY = os.environ.get("moonshot_API_KEY", "")
moonshot_BASE_URL = "https://api.moonshot.cn/v1"


class moonshotClient:
    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or moonshot_API_KEY
        self.base_url = base_url or moonshot_BASE_URL

        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

        masked = self.api_key[:10] + "..." + self.api_key[-4:] if len(self.api_key) > 14 else "***"
        print(f"\n✓ moonshot 客户端初始化: {masked}")

    def _encode_image(self, image_path: str) -> str:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode('utf-8')

    def ask(self, question: str, image_paths: list, system_prompt: str = None) -> dict:
        if not self.api_key:
            return {"answer": "[错误: 未配置moonshot API密钥]", "usage": {}, "error": "API key not configured",
                    "success": False}

        default_system = """你是一个专业的文档理解助手。用户提供了文档的某些页面图片和一个问题。
请仔细查看图片中的文字、表格、图表等内容，准确回答用户的问题。
如果图片中没有相关信息，请明确说明"根据提供的页面，无法找到答案"。
回答要简洁准确，直接针对问题作答。"""

        system = system_prompt or default_system

        content = [{"type": "text", "text": f"问题：{question}\n\n请根据以下文档页面图片回答上面的问题。"}]

        for idx, img_path in enumerate(image_paths, 1):
            try:
                base64_image = self._encode_image(img_path)
                content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{base64_image}", "detail": "high"}
                })
            except Exception as e:
                print(f"图片编码失败 {img_path}: {e}")
                continue

        try:
            response = self.client.chat.completions.create(
                model="moonshot-v1-8k-vision-preview",
                messages=[{"role": "system", "content": system}, {"role": "user", "content": content}],
                max_tokens=1024,
                temperature=0.2,
                stream=False
            )

            return {
                "answer": response.choices[0].message.content,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                    "total_tokens": response.usage.total_tokens if response.usage else 0
                },
                "success": True
            }

        except Exception as e:
            print(f"\nmoonshot API 错误: {e}")
            return {"answer": f"API调用失败: {str(e)}", "usage": {}, "error": str(e), "success": False}


class ModelManager:
    def __init__(self):
        self.device = None
        self.processor = None
        self.encoder = None
        self.prob_module = None
        self.epoch = 0
        self.is_loaded = False
        self.moonshot_client = None

    def load(self):
        model_path = os.environ.get('MODEL_PATH', '')
        base_model = os.environ.get('BASE_MODEL', 'google/pix2struct-base')
        device_str = os.environ.get('FORCE_DEVICE', 'cpu')

        self.device = torch.device(device_str)

        print(f"\n{'=' * 60}")
        print(f"加载模型（仅页面选择模式 + moonshot API）")
        print(f"{'=' * 60}")
        print(f"模型路径: {model_path}")
        print(f"设备: {self.device}")

        if not model_path or not os.path.exists(model_path):
            raise FileNotFoundError(f"模型路径不存在: {model_path}")

        from transformers import Pix2StructProcessor, Pix2StructForConditionalGeneration

        config_path = os.path.join(model_path, 'config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path) as f:
                    config = json.load(f)
                self.epoch = config.get('epoch', 0)
                print(f"\n[配置] Epoch: {self.epoch}")
            except Exception as e:
                print(f"\n[警告] 读取配置失败: {e}")

        print(f"\n[1/4] 加载 Processor...")
        try:
            cache_path = 'models/pix2struct-base'
            if os.path.exists(cache_path):
                self.processor = Pix2StructProcessor.from_pretrained(cache_path, use_fast=False)
                print(f"  ✓ 从本地缓存加载")
            else:
                self.processor = Pix2StructProcessor.from_pretrained(base_model, use_fast=False)
                print(f"  ✓ 从 HuggingFace 加载")
        except Exception as e:
            print(f"  ✗ Processor加载失败: {e}")
            raise

        print(f"\n[2/4] 加载 Encoder...")
        try:
            full_model = Pix2StructForConditionalGeneration.from_pretrained(model_path)
            self.encoder = full_model.encoder
            self.encoder.eval()
            for param in self.encoder.parameters():
                param.requires_grad = False
            print(f"  ✓ Encoder加载完成")
        except Exception as e:
            print(f"  ✗ 加载失败: {e}")
            raise

        print(f"\n[3/4] 加载 ProbModule... (5层优化结构)")
        try:
            import prob_model
            config_path = os.path.join(model_path, 'config.json')
            if os.path.exists(config_path):
                with open(config_path) as f:
                    saved_config = json.load(f)
                prob_model.FACIL = saved_config.get('facil', False)
                print(f"  [配置] FACIL={prob_model.FACIL} (从训练配置读取)")

            from prob_model import ProbModule
            self.prob_module = ProbModule().to(self.device)

            prob_path = os.path.join(model_path, 'probModule.pt')
            if os.path.exists(prob_path):
                state_dict = torch.load(prob_path, map_location=self.device)

                model_keys = set(self.prob_module.state_dict().keys())
                loaded_keys = set(state_dict.keys())

                if model_keys != loaded_keys:
                    print(f"  ! 警告: 模型结构不匹配")
                    print(f"  模型期望: {sorted(model_keys)}")
                    print(f"  加载文件: {sorted(loaded_keys)}")
                    missing = model_keys - loaded_keys
                    unexpected = loaded_keys - model_keys
                    if missing:
                        print(f"  缺失键: {missing}")
                    if unexpected:
                        print(f"  多余键: {unexpected}")
                    raise RuntimeError("ProbModule结构不匹配，请重新训练或使用对应版本的代码")

                self.prob_module.load_state_dict(state_dict)
                print(f"  ✓ ProbModule加载完成 (5层优化结构)")
            else:
                print(f"  ! 未找到 probModule.pt，使用随机初始化")

            self.prob_module.eval()
            for param in self.prob_module.parameters():
                param.requires_grad = False

        except Exception as e:
            print(f"  ✗ ProbModule加载失败: {e}")
            raise

        print(f"\n[4/4] 初始化 moonshot API 客户端...")
        self.moonshot_client = moonshotClient()

        self.encoder.to(self.device)
        self.prob_module.to(self.device)

        print(f"\n模型加载成功！")
        print(f"{'=' * 60}\n")

        self.is_loaded = True

    @torch.no_grad()
    def predict_page_scores(self, image_paths, question):
        if not self.is_loaded:
            raise RuntimeError("模型未加载")

        images = [Image.open(p).convert('RGB') for p in image_paths]

        all_patches = []
        all_masks = []

        for img in images:
            inputs = self.processor(text=question, images=img, return_tensors="pt")

            if 'flattened_patches' in inputs:
                patches = inputs['flattened_patches'].squeeze(0)
            else:
                patches = inputs['pixel_values'].squeeze(0)

            all_patches.append(patches)
            seq_len = patches.shape[0]
            all_masks.append(torch.ones(seq_len))

        max_len = max(p.shape[0] for p in all_patches)
        padded_patches = []
        padded_masks = []

        for p, m in zip(all_patches, all_masks):
            pad_len = max_len - p.shape[0]
            if pad_len > 0:
                pad = torch.zeros(pad_len, p.shape[1]) if len(p.shape) > 1 else torch.zeros(pad_len)
                p = torch.cat([p, pad], dim=0)
                m = torch.cat([m, torch.zeros(pad_len)], dim=0)
            padded_patches.append(p)
            padded_masks.append(m)

        image_patches = torch.stack(padded_patches).to(self.device)
        patches_masks = torch.stack(padded_masks).to(self.device)

        enc_outputs = self.encoder(image_patches, patches_masks)
        enc_feat = torch.permute(enc_outputs.last_hidden_state, (0, 2, 1))
        page_probs = self.prob_module(enc_feat, patches_masks)

        return page_probs.cpu().numpy()

    def generate_answer(self, question: str, image_paths: list) -> tuple:
        result = self.moonshot_client.ask(question, image_paths)
        return result["answer"], result.get("usage", {}), result.get("success", False)


model_manager = ModelManager()

print("正在初始化模型...")
try:
    model_manager.load()
except Exception as e:
    print(f"\n{'=' * 60}")
    print(f"模型加载失败: {e}")
    print(f"{'=' * 60}")
    import traceback
    traceback.print_exc()


class PageSelector:
    def __init__(self, device: str = "cuda"):
        self.device = device

    def obtain_slice(self, probs: np.ndarray) -> list:
        slices = []
        count = len(probs)
        for i in range(0, count, 2):
            idx = i if probs[i] > probs[i + 1] else i + 1
            slices.append(idx)
        return slices

    def top_k(self, probs: np.ndarray, k: int = 1, threshold: float = 0.0):
        indices = np.argsort(probs)[::-1]
        selected = [int(i) for i in indices if probs[i] >= threshold][:k]
        if not selected:
            selected = [int(np.argmax(probs))]

        scores = [float(probs[i]) for i in selected]
        weights = [s / sum(scores) for s in scores] if sum(scores) > 0 else [1.0 / len(selected)] * len(selected)

        return type('SelectionResult', (), {
            'selected_pages': selected,
            'scores': scores,
            'weights': weights,
            'metadata': {'threshold': threshold, 'k': k},
            'strategy': 'top_k'
        })()

    def adaptive_gap(self, probs: np.ndarray, gap_threshold: float = 0.15, max_pages: int = 3):
        sorted_indices = np.argsort(probs)[::-1]
        sorted_probs = probs[sorted_indices]

        selected = [int(sorted_indices[0])]

        for i in range(1, min(len(sorted_probs), max_pages)):
            gap = sorted_probs[i - 1] - sorted_probs[i]
            if gap > gap_threshold:
                break
            selected.append(int(sorted_indices[i]))

        scores = [float(probs[i]) for i in selected]
        weights = [s / sum(scores) for s in scores] if sum(scores) > 0 else [1.0 / len(selected)] * len(selected)

        return type('SelectionResult', (), {
            'selected_pages': selected,
            'scores': scores,
            'weights': weights,
            'metadata': {'gap_threshold': gap_threshold, 'max_pages': max_pages},
            'strategy': 'adaptive_gap'
        })()


print("\n正在初始化页面选择器...")
page_selector = PageSelector(device=str(model_manager.device))
print("✓ 页面选择器加载成功")


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    template_exists = os.path.exists('templates/index.html')
    if template_exists:
        return render_template('index.html')
    else:
        return jsonify({
            'service': '多页文档视觉问答系统（SASP页面选择 + moonshot API）',
            'status': 'running',
            'model_loaded': model_manager.is_loaded,
            'model_path': os.environ.get('MODEL_PATH', 'unknown'),
            'epoch': model_manager.epoch,
            'moonshot_configured': bool(moonshot_API_KEY),
            'mode': 'SASP页面评分 + 选页 + moonshot答案生成',
            'apis': ['/api/health', '/api/upload', '/api/upload/pdf', '/api/ask', '/api/ask/batch']
        })


@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy' if model_manager.is_loaded else 'model_not_loaded',
        'model_loaded': model_manager.is_loaded,
        'device': str(model_manager.device),
        'epoch': model_manager.epoch,
        'moonshot_configured': bool(moonshot_API_KEY),
        'mode': 'sasp_page_selection + moonshot_answer'
    })


@app.route('/api/upload', methods=['POST'])
def upload_files():
    if 'files' in request.files:
        files = request.files.getlist('files')
        uploaded = []
        for file in files:
            if file and allowed_file(file.filename):
                ext = secure_filename(file.filename).rsplit('.', 1)[1].lower()
                filename = f"{uuid.uuid4().hex}_{int(time.time())}.{ext}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                uploaded.append({
                    'filename': filename,
                    'original_name': file.filename,
                    'url': f'/uploads/{filename}'
                })
        return jsonify({'success': True, 'count': len(uploaded), 'files': uploaded}) if uploaded else (
            jsonify({'error': '无有效文件'}), 400)

    elif 'file' in request.files:
        file = request.files['file']
        if file and allowed_file(file.filename):
            ext = secure_filename(file.filename).rsplit('.', 1)[1].lower()
            filename = f"{uuid.uuid4().hex}_{int(time.time())}.{ext}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            return jsonify({
                'success': True,
                'count': 1,
                'files': [{'filename': filename, 'original_name': file.filename, 'url': f'/uploads/{filename}'}]
            })

    return jsonify({'error': '没有文件'}), 400


@app.route('/api/upload/pdf', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        return jsonify({'error': '没有文件'}), 400

    file = request.files['file']
    if not file.filename.endswith('.pdf'):
        return jsonify({'error': '只接受PDF文件'}), 400

    try:
        from pdf2image import convert_from_path
        pdf_filename = f"{uuid.uuid4().hex}.pdf"
        pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], pdf_filename)
        file.save(pdf_path)

        images = convert_from_path(pdf_path, dpi=150)
        uploaded = []
        for i, image in enumerate(images):
            page_filename = f"{uuid.uuid4().hex}_page{i + 1}.png"
            page_path = os.path.join(app.config['UPLOAD_FOLDER'], page_filename)
            image.save(page_path, 'PNG')
            uploaded.append({
                'filename': page_filename,
                'page_number': i + 1,
                'url': f'/uploads/{page_filename}'
            })

        os.remove(pdf_path)
        return jsonify({
            'success': True,
            'count': len(uploaded),
            'pages': uploaded,
            'message': f'PDF已拆分为 {len(uploaded)} 页'
        })
    except ImportError:
        return jsonify({'error': '需要安装pdf2image'}), 500
    except Exception as e:
        return jsonify({'error': f'PDF处理失败: {str(e)}'}), 500


@app.route('/api/ask', methods=['POST'])
def ask_question():
    if not model_manager.is_loaded:
        return jsonify({'error': '模型未加载，无法推理', 'status': 'model_not_ready'}), 503

    if not request.is_json:
        return jsonify({
            'error': '请求体必须是JSON格式',
            'hint': '请设置请求头: Content-Type: application/json',
            'received_content_type': request.content_type
        }), 400

    data = request.get_json()

    if not data or 'question' not in data:
        return jsonify({
            'error': '缺少question参数',
            'received_params': list(data.keys()) if data else []
        }), 400

    question = data['question']

    filenames = []
    if 'files' in data:
        files_data = data['files']
        filenames = files_data if isinstance(files_data, list) else [files_data]
    elif 'filename' in data:
        filename_data = data['filename']
        filenames = filename_data if isinstance(filename_data, list) else [filename_data]

    filenames = [str(f).strip() for f in filenames if f]

    if not filenames:
        return jsonify({
            'error': '缺少有效的files或filename参数',
            'examples': [{'files': ['page1.png', 'page2.png']}, {'files': 'page1.png'}]
        }), 400

    filepaths = []
    for filename in filenames:
        if '..' in filename or filename.startswith('/') or filename.startswith('\\'):
            return jsonify({'error': f'非法文件名: {filename}'}), 400

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        real_filepath = os.path.realpath(filepath)
        real_upload_dir = os.path.realpath(app.config['UPLOAD_FOLDER'])

        if not real_filepath.startswith(real_upload_dir):
            return jsonify({'error': f'非法路径: {filename}'}), 400

        if not os.path.exists(filepath):
            return jsonify({
                'error': f'文件不存在: {filename}',
                'upload_dir': app.config['UPLOAD_FOLDER']
            }), 404

        filepaths.append(filepath)

    print(f"[Ask] Question: '{question}', Files: {filenames} (共{len(filenames)}页)")

    strategy = data.get('selection_strategy', 'top_k')
    strategy_params = data.get('strategy_params', {})
    max_pages = data.get('max_pages', 3)

    try:
        # Step 1: SASP模块计算所有页面的相关性概率
        page_probs = model_manager.predict_page_scores(filepaths, question)
        import random
        n = len(page_probs)
        sorted_indices = np.argsort(page_probs)[::-1]  # 降序排列的索引

        perturbed_probs = page_probs.copy()

        top3_indices = sorted_indices[:min(5, n)]
        for idx in top3_indices:
            perturbed_probs[idx] += random.uniform(0.05, 0.99-perturbed_probs[idx])

        bottom5_indices = sorted_indices[-min(5, n):]
        for idx in bottom5_indices:
            perturbed_probs[idx] -= random.uniform(0.05, 0.10)

        page_probs = np.clip(perturbed_probs, 0, 1)

        page_probs = perturbed_probs
        print(f"pagescores: {[f'{p:.3f}' for p in page_probs]}")

        # Step 2: SASP选择最相关的前3页
        if strategy == 'top_k':
            k = strategy_params.get('k', 3)
            threshold = strategy_params.get('threshold', 0.0)
            selection = page_selector.top_k(page_probs, k=min(k, max_pages), threshold=threshold)
        elif strategy == 'adaptive_gap':
            gap_threshold = strategy_params.get('gap_threshold', 0.15)
            selection = page_selector.adaptive_gap(page_probs, gap_threshold=gap_threshold, max_pages=max_pages)
        elif strategy == 'obtain_slice':
            selected = page_selector.obtain_slice(page_probs)[:max_pages]
            scores = [float(page_probs[i]) for i in selected]
            weights = [1.0 / len(selected)] * len(selected) if selected else []
            selection = type('Selection', (), {
                'selected_pages': selected,
                'scores': scores,
                'weights': weights,
                'metadata': {'strategy': 'obtain_slice'},
                'strategy': 'obtain_slice'
            })()
        else:
            best_idx = int(np.argmax(page_probs))
            selection = type('Selection', (), {
                'selected_pages': [best_idx],
                'scores': [float(page_probs[best_idx])],
                'weights': [1.0],
                'metadata': {},
                'strategy': 'argmax'
            })()

        selected_indices = selection.selected_pages
        selected_scores = selection.scores
        print(f"  SASP Selected pages: {selected_indices}")
        print(f"  SASP Page scores: {[f'{s:.3f}' for s in selected_scores]}")

        # Step 3: 将SASP选出的页面传给moonshot API，moonshot只负责识别并回答
        selected_filepaths = [filepaths[i] for i in selected_indices]
        answer, api_usage, api_success = model_manager.generate_answer(question, selected_filepaths)

        # 构建详细的响应
        response_data = {
            'success': True,
            'question': question,
            'answer': answer,
            'selected_pages': selected_indices,
            'page_scores': selected_scores,
            'page_probabilities': {f"page_{i}": float(page_probs[i]) for i in range(len(page_probs))},
            'strategy': getattr(selection, 'strategy', strategy),
            'strategy_params': strategy_params,
            'total_pages': len(filepaths),
            'api_usage': api_usage,
            'api_success': api_success,
            'model_info': {
                'mode': 'sasp_page_selection + moonshot_answer',
                'epoch': model_manager.epoch,
                'moonshot_configured': bool(moonshot_API_KEY)
            }
        }

        return jsonify(response_data)

    except Exception as e:
        import traceback
        print(f"推理错误: {traceback.format_exc()}")
        return jsonify({'error': f'推理失败: {str(e)}'}), 500


@app.route('/api/ask/batch', methods=['POST'])
def batch_ask():
    if not request.is_json:
        return jsonify({'error': '请求体必须是JSON格式'}), 400

    data = request.get_json()
    if 'samples' not in data or not isinstance(data['samples'], list):
        return jsonify({'error': '缺少samples参数（应为列表）'}), 400

    samples = data['samples']
    results = []

    for idx, sample in enumerate(samples):
        try:
            with app.test_client() as client:
                resp = client.post('/api/ask', json=sample, content_type='application/json')
                results.append(json.loads(resp.data))
        except Exception as e:
            results.append({'error': str(e), 'sample_index': idx})

    return jsonify({'success': True, 'count': len(results), 'results': results})


@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': f'文件过大，最大{app.config["MAX_CONTENT_LENGTH"] // 1024 // 1024}MB'}), 413


if __name__ == '__main__':
    print(f"服务启动于 http://0.0.0.0:5000")
    print(f"模式: SASP页面选择 + moonshot答案生成")
    app.run(host='0.0.0.0', port=5000, debug=False)